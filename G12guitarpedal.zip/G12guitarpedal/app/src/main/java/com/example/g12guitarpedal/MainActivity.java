package com.example.g12guitarpedal;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.content.Intent;


import android.os.Bundle;
import android.widget.Toast;

import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private BluetoothAdapter myAdapter;
    private Intent btIntent, serviceIntent;
    private final static int btRequestCode = 1; //value of our choosing, greater than 0

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myAdapter = BluetoothAdapter.getDefaultAdapter();
        btIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        serviceIntent = new Intent(this,BTService.class);
    }

    //Each of the following Effect#() methods corresponds to one of the effect buttons and opens the correct new activity
    public void Effect1(View effectButton){
        Intent i = new Intent(this, Effect1.class);
        startActivity(i);
    }

    public void Effect2(View effectButton){
        Intent i = new Intent(this, Effect2.class);
        startActivity(i);
    }

    public void Effect3(View effectButton){
        Intent i = new Intent(this, Effect3.class);
        startActivity(i);
    }

    public void Effect4(View effectButton){
        Intent i = new Intent(this, Effect4.class);
        startActivity(i);
    }

    public void Effect5(View effectButton){
        Intent i = new Intent(this, Effect5.class);
        startActivity(i);
    }

    public void Effect6(View effectButton){
        Intent i = new Intent(this, Effect6.class);
        startActivity(i);
    }

    public void Effect7(View effectButton){
        Intent i = new Intent(this, Effect7.class);
        startActivity(i);
    }

    //creating the action bar with the Bluetooth options icon (code help from https://developer.android.com/guide/topics/ui/menus#java)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater myInflater = getMenuInflater();
        myInflater.inflate(R.menu.btmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        switch(item.getItemId()) {
            case R.id.enableBT:
                attemptBTEnable();
                return true;
            case R.id.connectBT:
                startService(serviceIntent);
                return true;
            case R.id.disconnectBT:
                stopService(serviceIntent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //This method checks if the user's device supports Bluetooth. If it does, they will be asked for permission to enable it
    private void attemptBTEnable() {
        if (myAdapter != null) {
            if(!myAdapter.isEnabled())  //request to enable bluetooth
                startActivityForResult(btIntent,btRequestCode);
            else
                makeToast("Bluetooth already enabled");
        }
        else {
            makeToast("Bluetooth not supported on this device");
        }
    }

    //This method checks the response of the user (whether they allowed or denied Bluetooth enabling)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == btRequestCode) {
            if(resultCode == RESULT_OK)
                makeToast("Bluetooth successfully enabled");
            else
                makeToast("Bluetooth enable cancelled");
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    //method to make toasts easier in code
    private void makeToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}