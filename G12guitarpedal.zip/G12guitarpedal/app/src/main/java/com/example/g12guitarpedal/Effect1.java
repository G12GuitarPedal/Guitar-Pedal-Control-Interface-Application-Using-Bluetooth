package com.example.g12guitarpedal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.SeekBar;
import android.widget.TextView;


public class Effect1 extends AppCompatActivity {
    private TextView selection1;
    private TextView selection2;
    private SeekBar seek1;
    private SeekBar seek2;
    private TextView selection3;
    private SeekBar seek3;
    BTService myBTService;
    boolean boundToService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_effect1);
        selection1 = (TextView)findViewById(R.id.textView2);
        seek1 = (SeekBar) findViewById(R.id.seekBar);
        selection2 = (TextView)findViewById(R.id.textView3);
        seek2 = (SeekBar)findViewById(R.id.seekBar2);
        selection3 = (TextView)findViewById(R.id.textView38);
        seek3 = (SeekBar)findViewById(R.id.seekBar15);
        seek1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int levelSelect1 = progress +1;
                String theLevel = Integer.toString(levelSelect1);
                selection1.setText("Level: "+ theLevel);
                myBTService.writeToDevice("data");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        seek2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int levelSelect2 = progress +1;
                String theLevel = Integer.toString(levelSelect2);
                selection2.setText("Level: "+ theLevel);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        seek3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int levelSelect3 = progress +1;
                String theLevel = Integer.toString(levelSelect3);
                selection3.setText("Level: "+ theLevel);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

    }

    //Got code help from https://developer.android.com/guide/components/bound-services#:~:text=A%20bound%20service%20is%20an,the%20onBind()%20callback%20method.
    private ServiceConnection servConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            BTService.LocalBinder binder = (BTService.LocalBinder) service;
            myBTService = binder.getService();
            boundToService = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            boundToService = false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, BTService.class);
        bindService(intent,servConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unbindService(servConnection);
        boundToService = false;
    }
}