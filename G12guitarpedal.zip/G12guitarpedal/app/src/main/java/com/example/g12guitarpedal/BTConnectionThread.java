package com.example.g12guitarpedal;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

public class BTConnectionThread extends Thread {
    private BluetoothSocket btSocket;
    private BluetoothDevice myDevice;
    private UUID myUUID = UUID.fromString("00001108-0000-1000-8000-00805F9B34FB"); //"00001101-0000-1000-8000-00805F9B34FB" for pi
    private boolean connected;

    //This method accepts a Bluetooth device (the Raspberry Pi) and attempts to create a BT socket
    public BTConnectionThread(BluetoothDevice device) {
        myDevice = device;
        BluetoothSocket temp = null;
        connected = false;
        try {
            temp = myDevice.createRfcommSocketToServiceRecord(myUUID);
        } catch (IOException e) {
            e.printStackTrace();
        }
        btSocket = temp;
    }

    //Returns the Bluetooth Socket
    public BluetoothSocket getBtSocket() {
        return btSocket;
    }

    public ConnectedThread connect() {
        try {
            btSocket.connect();
            connected = true;
            return new ConnectedThread(btSocket);
        } catch (IOException eConnect) {
            try {
                btSocket.close();
            } catch (IOException eClose) { }
        }
        return null;
    }

    //Getter method for connected
    public boolean isConnected() {
        return connected;
    }

    //Setter method for connected
    public void setConnected(boolean state) {
        connected = state;
    }

    //Called to finish thread and stop Bluetooth connection between the 2 devices
    public boolean cancel() {
        try{
            btSocket.close();
            connected = false;
            return true;
        } catch (IOException e) {
            return false;
        }
    }

}

class ConnectedThread extends Thread {
    private final BluetoothSocket socket;
    private final OutputStream outStream;
    byte[] dataBytes;

    public ConnectedThread(BluetoothSocket btsocket) {
        socket = btsocket;
        OutputStream temp = null;

        try {
            temp = socket.getOutputStream();
        } catch (IOException e) {
            Log.e("mytag", "Error occurred when creating input stream", e);
        }
        outStream = temp;
    }

    public boolean write (String data) {
        dataBytes = data.getBytes();
        try {
            outStream.write(dataBytes);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

}


