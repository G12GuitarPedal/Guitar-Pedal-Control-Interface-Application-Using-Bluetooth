package com.example.g12guitarpedal;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.IBinder;
import android.widget.Toast;

import java.util.Set;


public class BTService extends Service {
    private ConnectedThread myConnectedThread;
    private BTConnectionThread myConnection;
    private BluetoothAdapter myAdapter;
    private BluetoothDevice rPi;
    private final IBinder myBinder = new LocalBinder();
    boolean allowRebind;

    //Got code help from https://developer.android.com/guide/components/bound-services#:~:text=A%20bound%20service%20is%20an,the%20onBind()%20callback%20method.
    public class LocalBinder extends Binder {
        BTService getService() {
            return BTService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();

        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        this.registerReceiver(myReceiver,filter);
    }

    //Got code help from https://stackoverflow.com/questions/4715865/how-to-programmatically-tell-if-a-bluetooth-device-is-connected
    private final BroadcastReceiver myReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

            if(BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                //Device has disconnected
                makeToast("Disconnected from device");
                myConnection.setConnected(false);
            }
            if(BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                makeToast("Connected to device");
            }
        }
    };

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        myConnection = null;
        myConnectedThread = null;
        myAdapter = BluetoothAdapter.getDefaultAdapter();
        makeToast("Bluetooth Service started");
        if (myAdapter.isEnabled()) {
            if (myConnection == null || !myConnection.isConnected()) {
                rPi = searchForPi();
                if (rPi != null) {
                    attemptBTConnect(rPi);
                } else
                    makeToast("Raspberry Pi not found in paired devices. Please pair in your device Settings");
            } else
                makeToast("Already connected to Raspberry Pi");
        } else
            makeToast("Please enable Bluetooth before trying to connect");
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // A client is binding to the service with bindService()
        return myBinder;
    }
    @Override
    public boolean onUnbind(Intent intent) {
        // All clients have unbound with unbindService()
        return allowRebind;
    }

    //Stopping and destroying service
    @Override
    public void onDestroy() {
        boolean cancelled = myConnection.cancel();
        if (cancelled)
            makeToast("Disconnected from device");
        makeToast("Bluetooth Service Stopped");
        unregisterReceiver(myReceiver);
        super.onDestroy();
    }

    //Method that will be called from the binded Activity's
    public void writeToDevice(String data) {
        boolean writeSuccessful;
        if (myConnectedThread != null) {
            writeSuccessful = myConnectedThread.write(data);
            if (writeSuccessful)
                makeToast("Write successful");
            else
                makeToast("Write was unsuccessful");
        } else
            makeToast("Please connect to Raspberry Pi");
    }

    //Method to make app messages easier to code
    public void makeToast(String message) {
        Toast.makeText(getApplicationContext(),message,Toast.LENGTH_LONG).show();
    }

    //This method accepts a Bluetooth device (the Raspberry Pi) and creates a new Thread to connect it with the user's device
    private void attemptBTConnect(BluetoothDevice rPi) {
        myConnection = new BTConnectionThread(rPi);

        if (myConnection.getBtSocket() != null) {
            myConnectedThread = myConnection.connect();
            if (myConnection.isConnected()) {
                makeToast("Successfully connected");
            } else
                makeToast("Connection failed");
        } else
            makeToast("Socket creation failed");
    }

    //Searches through the user's paired devices and returns the Raspberry Pi device if it is found. Returns null otherwise and tells the user to pair first.
    private BluetoothDevice searchForPi() {
        Set<BluetoothDevice> pairedDevices = myAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                if(device.getName().equals("Hesh 2 Wireless")) //change to raspberry Pi address later
                    return device;
            }
        }
        return null;
    }
}