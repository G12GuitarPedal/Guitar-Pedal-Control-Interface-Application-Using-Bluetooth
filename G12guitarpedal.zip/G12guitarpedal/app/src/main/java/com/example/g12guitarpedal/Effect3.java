package com.example.g12guitarpedal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class Effect3 extends AppCompatActivity {
    private TextView selection1;
    private TextView selection2;
    private SeekBar seek1;
    private SeekBar seek2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_effect3);
        selection1 = (TextView)findViewById(R.id.textView5);
        seek1 = (SeekBar) findViewById(R.id.seekBar3);
        selection2 = (TextView)findViewById(R.id.textView6);
        seek2 = (SeekBar)findViewById(R.id.seekBar4);
        seek1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int levelSelect1 = progress +1;
                String theLevel = Integer.toString(levelSelect1);
                selection1.setText("Level: "+ theLevel);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        seek2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int levelSelect2 = progress +1;
                String theLevel = Integer.toString(levelSelect2);
                selection2.setText("Level: "+ theLevel);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

    }


}